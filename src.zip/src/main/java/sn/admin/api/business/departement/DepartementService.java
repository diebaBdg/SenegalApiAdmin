package sn.admin.api.business.departement;

import java.util.List;

public interface DepartementService {
    List<DepartementDTO> getByRegion(Long regionId);
}