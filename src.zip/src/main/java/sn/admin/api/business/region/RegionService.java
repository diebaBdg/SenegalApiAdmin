package sn.admin.api.business.region;

import java.util.List;

public interface RegionService {
    List<RegionDTO> getAll();
}