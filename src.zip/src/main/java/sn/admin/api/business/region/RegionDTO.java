package sn.admin.api.business.region;

import lombok.Data;

@Data
public class RegionDTO {
    private Long id;
    private String name;
}
