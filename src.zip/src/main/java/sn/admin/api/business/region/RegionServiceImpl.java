package sn.admin.api.business.region;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RegionServiceImpl implements RegionService {

    private final RegionRepository repo;
    private final RegionMapper mapper;

    // Constructeur explicite pour injection
    public RegionServiceImpl(RegionRepository repo, RegionMapper mapper) {
        this.repo = repo;
        this.mapper = mapper;
    }

    @Override
    public List<RegionDTO> getAll() {
        return repo.findAll().stream().map(mapper::toDto).toList();
    }
}
