package sn.admin.api.business.region;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/regions")
@Tag(name = "Régions", description = "Endpoints pour gérer les régions du Sénégal")
public class RegionController {

    private final RegionService service;

    // Constructeur explicite pour injection
    public RegionController(RegionService service) {
        this.service = service;
    }

    @GetMapping
    @Operation(summary = "Lister toutes les régions", description = "Retourne la liste complète des régions du Sénégal")
    public List<RegionDTO> getAllRegions() {
        return service.getAll();
    }
}
