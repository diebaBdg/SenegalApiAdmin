package sn.admin.api.business.commune;

import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class CommuneServiceImpl implements CommuneService {

    private final CommuneRepository repo;
    private final CommuneMapper mapper;

    public CommuneServiceImpl(CommuneRepository repo, CommuneMapper mapper) {
        this.repo = repo;
        this.mapper = mapper;
    }

    @Override
    public List<CommuneDTO> getByDepartement(Long departementId) {
        return repo.findByDepartementId(departementId).stream()
                .map(mapper::toDto)
                .toList();
    }
}
