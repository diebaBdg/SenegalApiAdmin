package sn.admin.api.business.departement;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/departements")
@Tag(name = "Départements", description = "Endpoints pour gérer les départements du Sénégal")
public class DepartementController {

    private final DepartementService service;

    // Constructeur explicite pour injecter le service
    public DepartementController(DepartementService service) {
        this.service = service;
    }

    @GetMapping("/region/{regionId}")
    @Operation(summary = "Lister les départements par région", description = "Retourne les départements appartenant à une région donnée")
    public List<DepartementDTO> getByRegion(@PathVariable Long regionId) {
        return service.getByRegion(regionId);
    }
}
