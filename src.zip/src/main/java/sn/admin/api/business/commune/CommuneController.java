package sn.admin.api.business.commune;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/communes")
@Tag(name = "Communes", description = "Endpoints pour gérer les communes du Sénégal")
public class CommuneController {

    private final CommuneService service;

    // Constructeur explicite
    public CommuneController(CommuneService service) {
        this.service = service;
    }

    @GetMapping("/departement/{departementId}")
    @Operation(summary = "Lister les communes par département", description = "Retourne toutes les communes appartenant à un département")
    public List<CommuneDTO> getByDepartement(@PathVariable Long departementId) {
        return service.getByDepartement(departementId);
    }
}
