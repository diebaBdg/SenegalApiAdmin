package sn.admin.api.business.commune;

import java.util.List;

public interface CommuneService {
    List<CommuneDTO> getByDepartement(Long departementId);
}